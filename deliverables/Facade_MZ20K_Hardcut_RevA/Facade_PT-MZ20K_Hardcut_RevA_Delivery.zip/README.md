# Facade Projection Layout — PT-MZ20K Portrait Hard Cut RevA

โมเดล SketchUp 2026 ที่สร้างจากรูปด้าน 1:100, ผังพื้น และภาพถ่ายที่ได้รับ

## ระบบฉาย

- Panasonic PT-MZ20K จำนวน 2 เครื่อง
- ฉาย Portrait 90°
- เลนส์ ET-EMS650
- ระยะ Lens-to-facade 20.00 m
- ระดับศูนย์เลนส์ +3.00 m
- Throw Ratio 1.493:1
- Full optical footprint ต่อเครื่อง 8.375 × 13.40 m
- Optical overlap 1.175 m ใช้เป็นพื้นที่เผื่อ Warp/Mask
- Active content แบ่ง Hard Cut ที่ Grid 16 / x=6.62 m
- ไม่มี Edge Blend และไม่มี Feather Ramp

## ภายในไฟล์ SKP

- Curved facade ribbons แยกตามช่วง Grid
- ช่องเปิดส่วนล่างและบันไดวนโดยประมาณ
- MZ20K body ขนาดจริงโดยประมาณ พร้อม ET-EMS650
- Truss tower 2 ชุด
- Full optical beam PJ-L/PJ-R
- Active zones สีน้ำเงิน/ส้ม
- Hard-cut marker สีเหลือง
- Tags แยก Site, Facade, Stairs, Rig, Projectors, Beams, Active Zones, Hard Cut และ Dimensions
- Scenes: Hero Perspective, Front Hard Cut, Top Beam Plan, Rig/Projectors และ Facade Geometry

## ข้อจำกัด

รูปทรงผิวโค้งและตำแหน่งร่องถอดจากภาพแบบ raster ความละเอียดประมาณ 1150 px จึงเป็น Coordination Model ไม่ใช่ As-built model ก่อนผลิต Mask ให้สำรวจตำแหน่งจริงด้วย Total Station/Laser Scan แล้วปรับเส้น Hard Cut ให้ตามร่องจริงบน UV/Warp ของแต่ละเครื่อง

